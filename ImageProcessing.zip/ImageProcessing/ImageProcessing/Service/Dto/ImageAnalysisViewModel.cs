﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;

namespace ImageProcessing.Service.Dto
{
    public class ImageAnalysisViewModel
    {
        public ImageAnalysis imageAnalysisResult { get; set; }
    }
}
