﻿using ImageProcessing.Service.Dto;

namespace ImageProcessing.Service
{
    public interface IComputerVisionService
    {
        Task<ImageAnalysisViewModel> AnalyzeImageUrl(string imageUrl);
    }
}
